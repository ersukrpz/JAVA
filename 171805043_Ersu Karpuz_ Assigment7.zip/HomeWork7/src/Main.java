import java.util.Scanner;
public class Main 
{
	public static void main(String[] args) 
	{
		Scanner giris = new Scanner(System.in);
		System.out.println("Please enter a color");
		String color = giris.next();
		System.out.println("Please enter a filled");
		boolean filled = giris.nextBoolean();
		System.out.println("Please enter a side");
		double side = giris.nextDouble();
		System.out.println("Please enter a radius");
		double radius = giris.nextDouble();
		
		System.out.println("Please enter a side");
		double side1 = giris.nextDouble();
		
		System.out.println("Please enter a width");
		double width = giris.nextDouble();
		System.out.println("Please enter a height");
		double height = giris.nextDouble();
		
		System.out.println("Please enter a side");
		double side2 = giris.nextDouble();
		
		GeometricObject obj = new Square(color, filled, side);
		GeometricObject obj1 = new Circle(color, filled, radius);
		GeometricObject obj2 = new Square(color, filled, side1);
		GeometricObject obj3 = new Rectangle(color, filled, width, height);
		GeometricObject obj4 = new Square(color, filled, side2);
		System.out.println(obj.toString());	
		System.out.println(obj1.toString());
		System.out.println(obj2.toString());
		System.out.println(obj3.toString());
		System.out.println(obj4.toString());
	}
}
