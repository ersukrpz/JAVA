public class Rectangle  extends GeometricObject  
{
	private double width;
	private double height;
	public Rectangle(String color, boolean filled,double width, double height)
	{
		super(color, filled);
		this.width = width;
		this.height = height;
	}
	public double getwidth()
	{
		return width;
	}
	public void setwidth(double width)
	{
		this.width = width;
	}
	public double getheight()
	{
		return height;
	}
	public void setheight(double height)
	{
		this.height = height;
	}
	public double getArea()
	{
		double Area = width * height;
		return Area;
	}
	public void howToColor()
	{
		
	}
	public String toString()
	{
		
		return "\n [Rectangle]" + super.toString() +  " width" + getwidth() + " ,height" + getheight() + "\n Area of object is" + getArea();
	}
}
