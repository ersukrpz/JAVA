import java.io.*; 
interface Colorable 
{
	public void howToColor();
	
}
