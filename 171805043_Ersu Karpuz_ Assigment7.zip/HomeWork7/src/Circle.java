public class Circle extends GeometricObject 
{
	private double PI = 3.14;
	private double radius;
	public Circle(String color, boolean filled,double radius)
	{
		super(color, filled);
		this.radius = radius;
	}
	public double getradius()
	{
		return radius;
	}
	public void setradius(double radius)
	{
		this.radius = radius ;
	}
	public double getArea()
	{
		double Area = PI*radius*radius;
		return Area;
	}
	public void howToColor()
	{
		
	}
	
	public String toString()
	{
		return  "\n [Circle]" + super.toString() + "\n radius:" + getradius() + "\n Area of object is" + getArea();
	}
}
