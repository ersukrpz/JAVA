public class Square extends GeometricObject  
{
	private double side;
	public Square(String color, boolean filled,double side)
	{
		super(color, filled);
		this.side = side;
	}
	public double getside()
	{
		return side;
	}
	public void setside(double side)
	{
		this.side = side;
	}
	public double getsides()
	{
		return side*side;
	}
	
	public void howToColor()
	{
		
	}
	public String toString()
	{
		
		return "\n [Square]" + super.toString() + "\n side:" + getside() + "\n Area Of Object" + getsides() ;
	}
}
